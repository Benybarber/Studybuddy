import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ReviewPage.css';

const ReviewPage = () => {
  const navigate = useNavigate();
  const [reviewTopics, setReviewTopics] = useState([]);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState('');
  const [noWeakTopics, setNoWeakTopics] = useState(false);

  const token = localStorage.getItem('token');

  useEffect(() => {
    const fetchReviewQuestions = async () => {
      if (!token) {
        setMessage('Please log in to review topics.');
        navigate('/');
        return;
      }

      try {
        const response = await fetch('/api/quiz/review', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          if (data.message) {
            // No weak topics
            setNoWeakTopics(true);
            setMessage(data.message);
          } else if (Array.isArray(data)) {
            setReviewTopics(data);
          }
        } else {
          const errorData = await response.json();
          setMessage(errorData.message || 'Failed to fetch review questions.');
        }
      } catch (error) {
        setMessage('Network error or server is unreachable.');
        console.error('Error fetching review questions:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchReviewQuestions();
  }, [navigate, token]);

  const handleAnswerChange = (topicIdx, qIdx, value) => {
    const key = `${topicIdx}-${qIdx}`;
    setAnswers({ ...answers, [key]: value });
  };

  const handleSubmitReview = () => {
    setSubmitted(true);
  };

  if (loading) {
    return <div className="review-container text-center"><p>Loading review questions...</p></div>;
  }

  return (
    <div className="review-container">
      <h1 className="text-center">Daily Review</h1>
      
      {noWeakTopics && (
        <div className="card text-center">
          <p>{message || 'No weak topics to review today. Keep up the good work!'}</p>
          <button onClick={() => navigate('/dashboard')}>Back to Dashboard</button>
        </div>
      )}

      {!noWeakTopics && message && <p className="error-message text-center">{message}</p>}

      {reviewTopics.length > 0 && reviewTopics.map((topicGroup, topicIdx) => (
        <div key={topicIdx} className="card review-topic-group">
          <h2>Topic: {topicGroup.topicTitle}</h2>
          {topicGroup.questions && topicGroup.questions.map((q, qIdx) => {
            const key = `${topicIdx}-${qIdx}`;
            const qType = q.type === 'multiple_choice' ? 'multiple-choice' : q.type;
            return (
              <div key={qIdx} className="review-question">
                <h3>Q{qIdx + 1}. {q.question}</h3>
                {qType === 'multiple-choice' && q.options && (
                  <div className="options-group">
                    {q.options.map((option) => (
                      <label key={option}>
                        <input
                          type="radio"
                          name={key}
                          value={option}
                          onChange={() => handleAnswerChange(topicIdx, qIdx, option)}
                          checked={answers[key] === option}
                          disabled={submitted}
                        />
                        {option}
                      </label>
                    ))}
                  </div>
                )}
                {qType === 'short-answer' && (
                  <textarea
                    rows="3"
                    placeholder="Type your answer here..."
                    value={answers[key] || ''}
                    onChange={(e) => handleAnswerChange(topicIdx, qIdx, e.target.value)}
                    disabled={submitted}
                  ></textarea>
                )}
                {submitted && (
                  <p className={`feedback ${answers[key] && q.answer && answers[key].toLowerCase() === q.answer.toLowerCase() ? 'correct' : 'incorrect'}`}>
                    {answers[key] && q.answer && answers[key].toLowerCase() === q.answer.toLowerCase()
                      ? '✓ Correct!'
                      : `✗ Incorrect. The correct answer is: ${q.answer}`}
                  </p>
                )}
              </div>
            );
          })}
        </div>
      ))}

      {!submitted && reviewTopics.length > 0 && (
        <button onClick={handleSubmitReview} className="submit-review-button">
          Submit Review
        </button>
      )}

      {submitted && (
        <div className="review-results card text-center">
          <h2>Review Complete!</h2>
          <button onClick={() => navigate('/dashboard')}>Back to Dashboard</button>
          <button onClick={() => { setSubmitted(false); setAnswers({}); navigate('/review'); }} style={{marginLeft: '10px'}}>
            Review Again
          </button>
        </div>
      )}
    </div>
  );
};

export default ReviewPage;
