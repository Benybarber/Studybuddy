import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import UpgradeModal from '../components/UpgradeModal';
import './Dashboard.css';

const Dashboard = () => {
  const [topics, setTopics] = useState([]);
  const [weakTopics, setWeakTopics] = useState([]);
  const [stats, setStats] = useState(null);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchDashboardData = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/');
        return;
      }

      try {
        // Fetch topics
        const topicsResponse = await fetch('/api/topics', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (topicsResponse.ok) {
          const topicsData = await topicsResponse.json();
          setTopics(topicsData);
        } else {
          console.error('Failed to fetch topics');
        }

        // Fetch weak topics
        const weakTopicsResponse = await fetch('/api/quiz/weak-topics', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (weakTopicsResponse.ok) {
          const weakTopicsData = await weakTopicsResponse.json();
          setWeakTopics(weakTopicsData);
        } else {
          console.error('Failed to fetch weak topics');
        }

        // Fetch stats
        const statsResponse = await fetch('/api/stats', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (statsResponse.ok) {
          const statsData = await statsResponse.json();
          setStats(statsData);
          if (statsData.quizzesTakenToday >= statsData.quizLimit) {
            setIsUpgradeModalOpen(true);
          }
        } else {
          console.error('Failed to fetch stats');
        }

      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        // Optionally, redirect to login if token is invalid or expired
        // navigate('/');
      }
    };

    fetchDashboardData();
  }, [navigate]);

  const handleNewStudySession = () => {
    navigate('/study');
  };

  const handleReviewWeakTopics = () => {
    navigate('/review');
  };

  return (
    <div className="dashboard-container">
      <h1 className="text-center">AI Study Buddy Dashboard</h1>

      <div className="dashboard-section card">
        <h2>Start New Study Session</h2>
        <button onClick={handleNewStudySession}>New Study Session</button>
      </div>

      {topics.length > 0 && (
        <div className="dashboard-section card">
          <h2>Your Topics</h2>
          <ul>
            {topics.map((topic) => (
              <li key={topic.id}>{topic.title}</li>
            ))}
          </ul>
        </div>
      )}

      {weakTopics.length > 0 && (
        <div className="dashboard-section card">
          <h2>Weak Topics</h2>
          <p>You struggle with: {weakTopics.map(t => t.title).join(', ')}</p>
          <button onClick={handleReviewWeakTopics}>Review Again</button>
        </div>
      )}

      <div className="dashboard-section card">
        <h2>Daily Review</h2>
        <p>Review your weak topics to improve your understanding.</p>
        <button onClick={handleReviewWeakTopics}>Start Daily Review</button>
      </div>

      {stats && (
        <div className="dashboard-section card">
          <h2>Your Stats</h2>
          <p>Quizzes taken today: {stats.quizzesTakenToday} / {stats.quizLimit}</p>
        </div>
      )}

      <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setIsUpgradeModalOpen(false)} />
    </div>
  );
};

export default Dashboard;
