const OpenAI = require("openai");

const openai = new OpenAI(); // API key is pre-configured via environment variable
const MODEL = "gpt-4.1-mini";

const generateExplanation = async (topicTitle, topicContent, style) => {
  let prompt;
  switch (style) {
    case "eli12":
      prompt = `Explain the following topic to a 12-year-old:
      Topic Title: ${topicTitle}
      Topic Content: ${topicContent}
      Provide key points in a JSON array format at the end of the explanation.`;
      break;
    case "step-by-step":
      prompt = `Provide a step-by-step explanation of the following topic:
      Topic Title: ${topicTitle}
      Topic Content: ${topicContent}
      Provide key points in a JSON array format at the end of the explanation.`;
      break;
    case "exam-focused":
      prompt = `Explain the following topic with a focus on what's important for an exam, including potential pitfalls and common questions:
      Topic Title: ${topicTitle}
      Topic Content: ${topicContent}
      Provide key points in a JSON array format at the end of the explanation.`;
      break;
    default:
      prompt = `Explain the following topic:
      Topic Title: ${topicTitle}
      Topic Content: ${topicContent}
      Provide key points in a JSON array format at the end of the explanation.`;
  }

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
    });
    const fullContent = completion.choices[0].message.content;
    const keyPointsMatch = fullContent.match(/\n\[.*\]/s);
    let explanationContent = fullContent;
    let keyPoints = [];

    if (keyPointsMatch) {
      try {
        keyPoints = JSON.parse(keyPointsMatch[0].trim());
        explanationContent = fullContent.replace(keyPointsMatch[0], "").trim();
      } catch (e) {
        console.warn("Could not parse key points JSON:", e);
      }
    }

    return { content: explanationContent, key_points: JSON.stringify(keyPoints) };
  } catch (error) {
    console.error("Error generating explanation:", error);
    throw new Error("Failed to generate explanation from OpenAI.");
  }
};

const generateQuizQuestions = async (topicTitle, topicContent) => {
  const prompt = `Generate 5-10 quiz questions (mix of multiple choice and short answer) for the following topic. Provide the questions in a JSON array format, where each object has 'type' (multiple_choice or short_answer), 'question', 'options' (for multiple_choice), and 'answer'.
  Topic Title: ${topicTitle}
  Topic Content: ${topicContent}`;

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
    });
    const questionsJson = completion.choices[0].message.content;
    return JSON.parse(questionsJson);
  } catch (error) {
    console.error("Error generating quiz questions:", error);
    throw new Error("Failed to generate quiz questions from OpenAI.");
  }
};

const generateReviewQuestions = async (topicTitle, topicContent) => {
  const prompt = `Generate 3 review questions (mix of multiple choice and short answer) for the following topic. Provide the questions in a JSON array format, where each object has 'type' (multiple_choice or short_answer), 'question', 'options' (for multiple_choice), and 'answer'.
  Topic Title: ${topicTitle}
  Topic Content: ${topicContent}`;

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
    });
    const questionsJson = completion.choices[0].message.content;
    return JSON.parse(questionsJson);
  } catch (error) {
    console.error("Error generating review questions:", error);
    throw new Error("Failed to generate review questions from OpenAI.");
  }
};

const getQuizFeedback = async (question, userAnswer, correctAnswer) => {
  const prompt = `The user answered the following question: "${question}" with "${userAnswer}". The correct answer is "${correctAnswer}". Provide feedback on the user's answer, explaining why it's correct or incorrect, and provide the correct explanation.`

  try {
    const completion = await openai.chat.completions.create({
      model: MODEL,
      messages: [{ role: "user", content: prompt }],
    });
    return completion.choices[0].message.content;
  } catch (error) {
    console.error("Error getting quiz feedback:", error);
    throw new Error("Failed to get quiz feedback from OpenAI.");
  }
};

module.exports = { generateExplanation, generateQuizQuestions, generateReviewQuestions, getQuizFeedback };
