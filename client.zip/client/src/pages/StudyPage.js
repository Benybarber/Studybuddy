import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import UpgradeModal from '../components/UpgradeModal';
import './StudyPage.css';

const StudyPage = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [style, setStyle] = useState('eli12');
  const [explanation, setExplanation] = useState(null);
  const [topicId, setTopicId] = useState(null);
  const [message, setMessage] = useState('');
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);
  const navigate = useNavigate();

  const token = localStorage.getItem('token');

  useEffect(() => {
    const checkQuizLimit = async () => {
      if (!token) return;
      try {
        const statsResponse = await fetch('/api/stats', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (statsResponse.ok) {
          const statsData = await statsResponse.json();
          if (statsData.quizzesTakenToday >= statsData.quizLimit) {
            setIsUpgradeModalOpen(true);
          }
        }
      } catch (error) {
        console.error('Error checking quiz limit:', error);
      }
    };
    checkQuizLimit();
  }, [token]);

  const handleGenerateExplanation = async () => {
    setMessage('');
    setExplanation(null);
    if (!token) {
      setMessage('Please log in to generate explanations.');
      navigate('/');
      return;
    }

    try {
      // First, create the topic
      const topicResponse = await fetch('/api/topics', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ title, content }),
      });

      if (!topicResponse.ok) {
        const errorData = await topicResponse.json();
        setMessage(errorData.message || 'Failed to create topic.');
        return;
      }
      const topicData = await topicResponse.json();
      const newTopicId = topicData.id || topicData.topicId;
      setTopicId(newTopicId);

      // Then, generate the explanation
      const explainResponse = await fetch('/api/explain', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ topicId: newTopicId, style }),
      });

      if (explainResponse.ok) {
        const explainData = await explainResponse.json();
        setExplanation(explainData);
      } else {
        const errorData = await explainResponse.json();
        setMessage(errorData.message || 'Failed to generate explanation.');
      }
    } catch (error) {
      setMessage('Network error or server is unreachable.');
      console.error('Error generating explanation:', error);
    }
  };

  const handleExplainDifferently = async () => {
    setMessage('');
    if (!token || !topicId) {
      setMessage('Please generate an initial explanation first.');
      return;
    }

    const styles = ['eli12', 'step-by-step', 'exam-focused'];
    const currentStyleIndex = styles.indexOf(style);
    const nextStyleIndex = (currentStyleIndex + 1) % styles.length;
    const newStyle = styles[nextStyleIndex];
    setStyle(newStyle); // Update style for display

    try {
      const response = await fetch('/api/explain/different', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ topicId, style: newStyle }),
      });

      if (response.ok) {
        const data = await response.json();
        setExplanation(data);
      } else {
        const errorData = await response.json();
        setMessage(errorData.message || 'Failed to generate different explanation.');
      }
    } catch (error) {
      setMessage('Network error or server is unreachable.');
      console.error('Error explaining differently:', error);
    }
  };

  const handleTakeQuiz = async () => {
    setMessage('');
    if (!token || !topicId) {
      setMessage('Please generate an explanation first to take a quiz.');
      return;
    }

    // Check quiz limit before allowing to take a quiz
    try {
      const statsResponse = await fetch('/api/stats', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        if (statsData.quizzesTakenToday >= statsData.quizLimit) {
          setIsUpgradeModalOpen(true);
          return;
        }
      }
    } catch (error) {
      console.error('Error checking quiz limit:', error);
      setMessage('Error checking quiz limit. Please try again.');
      return;
    }

    try {
      const response = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ topicId }),
      });

      if (response.ok) {
        const data = await response.json();
        navigate(`/quiz/${data.quizId}`, { state: { questions: data.questions } });
      } else {
        const errorData = await response.json();
        setMessage(errorData.message || 'Failed to generate quiz.');
      }
    } catch (error) {
      setMessage('Network error or server is unreachable.');
      console.error('Error generating quiz:', error);
    }
  };

  return (
    <div className="study-container">
      <h1 className="text-center">New Study Session</h1>
      <div className="card study-input-section">
        <input
          type="text"
          placeholder="Topic Title (e.g., 'React Hooks')"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <textarea
          placeholder="Enter notes, textbook text, or a detailed topic description..."
          rows="10"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        ></textarea>
        <div className="style-selector flex-container">
          <button
            className={style === 'eli12' ? 'active' : ''}
            onClick={() => setStyle('eli12')}
          >
            Explain like I'm 12
          </button>
          <button
            className={style === 'step-by-step' ? 'active' : ''}
            onClick={() => setStyle('step-by-step')}
          >
            Step-by-step
          </button>
          <button
            className={style === 'exam-focused' ? 'active' : ''}
            onClick={() => setStyle('exam-focused')}
          >
            Exam-focused
          </button>
        </div>
        <button onClick={handleGenerateExplanation} disabled={!title || !content}>
          Generate Explanation
        </button>
        {message && <p className="error-message">{message}</p>}
      </div>

      {explanation && (
        <div className="card explanation-section">
          <h2>Explanation ({style.replace('-', ' ')})</h2>
          <p>{explanation.content}</p>
          {explanation.key_points && explanation.key_points.length > 0 && (
            <div>
              <h3>Key Points:</h3>
              <ul>
                {explanation.key_points.map((point, index) => (
                  <li key={index}>{point}</li>
                ))}
              </ul>
            </div>
          )}
          <div className="flex-container explanation-actions">
            <button onClick={handleExplainDifferently}>Explain Differently</button>
            <button onClick={handleTakeQuiz}>Take Quiz</button>
          </div>
        </div>
      )}
      <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setIsUpgradeModalOpen(false)} />
    </div>
  );
};

export default StudyPage;
