import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import './QuizPage.css';

const QuizPage = () => {
  const { quizId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [quiz, setQuiz] = useState(null);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [results, setResults] = useState(null);
  const [message, setMessage] = useState('');

  const token = localStorage.getItem('token');

  useEffect(() => {
    // Quiz questions are passed via location state from StudyPage
    if (location.state && location.state.questions) {
      const questions = location.state.questions.map((q, index) => ({
        id: index,
        type: q.type === 'multiple_choice' ? 'multiple-choice' : 'short-answer',
        question: q.question,
        options: q.options || [],
      }));
      setQuiz({ quizId, questions });
    } else {
      // Fallback: try to fetch from backend
      const fetchQuiz = async () => {
        if (!token) {
          setMessage('Please log in to take quizzes.');
          navigate('/');
          return;
        }
        try {
          const response = await fetch(`/api/quiz/${quizId}`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          if (response.ok) {
            const data = await response.json();
            const questions = data.questions.map((q, index) => ({
              id: index,
              type: q.type === 'multiple_choice' ? 'multiple-choice' : 'short-answer',
              question: q.question,
              options: q.options || [],
            }));
            setQuiz({ quizId, questions });
          } else {
            setMessage('Could not load quiz. Please go back and try again.');
          }
        } catch (error) {
          setMessage('Error loading quiz: ' + error.message);
        }
      };
      fetchQuiz();
    }
  }, [quizId, navigate, token, location.state]);

  const handleAnswerChange = (questionId, value) => {
    setAnswers({ ...answers, [questionId]: value });
  };

  const handleSubmitQuiz = async () => {
    setMessage('');
    if (!token) {
      setMessage('Please log in to submit quizzes.');
      navigate('/');
      return;
    }

    // Build answers array in order
    const orderedAnswers = [];
    if (quiz && quiz.questions) {
      for (let i = 0; i < quiz.questions.length; i++) {
        orderedAnswers.push(answers[i] || '');
      }
    }

    try {
      const response = await fetch('/api/quiz/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ quizId: parseInt(quizId), answers: orderedAnswers }),
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data);
        setSubmitted(true);
      } else {
        const errorData = await response.json();
        setMessage(errorData.message || 'Failed to submit quiz.');
      }
    } catch (error) {
      setMessage('Network error or server is unreachable.');
      console.error('Error submitting quiz:', error);
    }
  };

  if (!quiz) {
    return <div className="quiz-container text-center">Loading quiz...</div>;
  }

  return (
    <div className="quiz-container">
      <h1 className="text-center">Quiz Time!</h1>
      {message && <p className="error-message text-center">{message}</p>}

      <div className="quiz-questions">
        {quiz.questions.map((q, index) => (
          <div key={q.id} className="card quiz-question">
            <h3>Q{index + 1}. {q.question}</h3>
            {q.type === 'multiple-choice' && q.options && (
              <div className="options-group">
                {q.options.map((option) => (
                  <label key={option}>
                    <input
                      type="radio"
                      name={`question-${q.id}`}
                      value={option}
                      onChange={() => handleAnswerChange(q.id, option)}
                      checked={answers[q.id] === option}
                      disabled={submitted}
                    />
                    {option}
                  </label>
                ))}
              </div>
            )}
            {q.type === 'short-answer' && (
              <textarea
                rows="3"
                placeholder="Type your answer here..."
                value={answers[q.id] || ''}
                onChange={(e) => handleAnswerChange(q.id, e.target.value)}
                disabled={submitted}
              ></textarea>
            )}
            {submitted && results && results.feedback && results.feedback[index] && (
              <p className={`feedback ${results.feedback[index].isCorrect ? 'correct' : 'incorrect'}`}>
                {results.feedback[index].isCorrect ? '✓ Correct!' : '✗ Incorrect.'} {results.feedback[index].explanation}
              </p>
            )}
          </div>
        ))}
      </div>

      {!submitted && (
        <button onClick={handleSubmitQuiz} className="submit-quiz-button">
          Submit Quiz
        </button>
      )}

      {submitted && results && (
        <div className="quiz-results card text-center">
          <h2>Quiz Results</h2>
          <p>You scored: {results.score} out of {results.total}</p>
          <button onClick={() => navigate('/dashboard')}>Back to Dashboard</button>
        </div>
      )}
    </div>
  );
};

export default QuizPage;
