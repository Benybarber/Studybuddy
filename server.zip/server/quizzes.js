const express = require('express');
const db = require('./db');
const { authenticateToken } = require('./auth');
const { generateQuizQuestions, generateReviewQuestions, getQuizFeedback } = require('./openaiService');

const router = express.Router();

const QUIZ_LIMIT_PER_DAY = 5;

// Helper to check daily quiz limit
const checkQuizLimit = (userId) => {
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  const stmt = db.prepare(
    'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND created_at LIKE ? || "%"'
  );
  const result = stmt.get(userId, today);
  return result.count;
};

// GET /api/quiz/:id - get quiz by ID
router.get('/:id', authenticateToken, (req, res) => {
  const quizId = req.params.id;
  try {
    const quiz = db.prepare('SELECT id, topic_id, questions, created_at FROM quizzes WHERE id = ?').get(quizId);
    if (!quiz) {
      return res.status(404).json({ message: 'Quiz not found' });
    }
    res.json({ quizId: quiz.id, questions: JSON.parse(quiz.questions) });
  } catch (error) {
    console.error('Error fetching quiz:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST /api/quiz/generate - generate quiz questions
router.post('/generate', authenticateToken, async (req, res) => {
  const { topicId } = req.body;
  const userId = req.user.userId;

  if (!topicId) {
    return res.status(400).json({ message: 'Topic ID is required' });
  }

  const quizzesTakenToday = checkQuizLimit(userId);
  if (quizzesTakenToday >= QUIZ_LIMIT_PER_DAY) {
    return res.status(403).json({ message: 'Free tier limit exceeded. Upgrade to generate more quizzes.' });
  }

  try {
    const topic = db.prepare('SELECT title, content FROM topics WHERE id = ? AND user_id = ?').get(topicId, userId);
    if (!topic) {
      return res.status(404).json({ message: 'Topic not found or does not belong to user' });
    }

    const questions = await generateQuizQuestions(topic.title, topic.content);
    const stmt = db.prepare('INSERT INTO quizzes (topic_id, questions) VALUES (?, ?)');
    const info = stmt.run(topicId, JSON.stringify(questions));

    res.status(201).json({ quizId: info.lastInsertRowid, questions });
  } catch (error) {
    console.error('Error generating quiz:', error);
    res.status(500).json({ message: error.message });
  }
});

// POST /api/quiz/submit - submit quiz answers
router.post('/submit', authenticateToken, async (req, res) => {
  const { quizId, answers } = req.body;
  const userId = req.user.userId;

  if (!quizId || !answers) {
    return res.status(400).json({ message: 'Quiz ID and answers are required' });
  }

  try {
    const quiz = db.prepare('SELECT questions, topic_id FROM quizzes WHERE id = ?').get(quizId);
    if (!quiz) {
      return res.status(404).json({ message: 'Quiz not found' });
    }

    const questions = JSON.parse(quiz.questions);
    let score = 0;
    const feedback = [];
    const wrongAnswers = [];

    for (let i = 0; i < questions.length; i++) {
      const question = questions[i];
      const userAnswer = answers[i] || '';
      const correctAnswer = question.answer || '';
      const isCorrect = correctAnswer.toLowerCase().trim() === userAnswer.toLowerCase().trim();

      if (isCorrect) {
        score++;
        feedback.push({ question: question.question, userAnswer, isCorrect: true, explanation: 'Correct!' });
      } else {
        wrongAnswers.push({ question: question.question, userAnswer, correctAnswer: question.answer });
        const explanation = await getQuizFeedback(question.question, userAnswer, question.answer);
        feedback.push({ question: question.question, userAnswer, isCorrect: false, explanation });
      }
    }

    // Save quiz attempt
    const stmtAttempt = db.prepare('INSERT INTO quiz_attempts (quiz_id, user_id, answers, score) VALUES (?, ?, ?, ?)');
    stmtAttempt.run(quizId, userId, JSON.stringify(answers), score);

    // Update weak topics
    for (const wrong of wrongAnswers) {
      const existingWeakTopic = db.prepare(
        'SELECT * FROM weak_topics WHERE user_id = ? AND topic_id = ?'
      ).get(userId, quiz.topic_id);

      if (existingWeakTopic) {
        db.prepare(
          'UPDATE weak_topics SET wrong_count = wrong_count + 1, last_wrong_at = CURRENT_TIMESTAMP WHERE id = ?'
        ).run(existingWeakTopic.id);
      } else {
        db.prepare(
          'INSERT INTO weak_topics (user_id, topic_id, wrong_count) VALUES (?, ?, 1)'
        ).run(userId, quiz.topic_id);
      }
    }

    res.json({ score, total: questions.length, feedback });
  } catch (error) {
    console.error('Error submitting quiz:', error);
    res.status(500).json({ message: error.message });
  }
});

// GET /api/weak-topics - get user's weak topics
router.get('/weak-topics', authenticateToken, (req, res) => {
  const userId = req.user.userId;

  try {
    const weakTopics = db.prepare(
      'SELECT wt.id, wt.topic_id, t.title, wt.wrong_count, wt.last_wrong_at FROM weak_topics wt JOIN topics t ON wt.topic_id = t.id WHERE wt.user_id = ? ORDER BY wt.wrong_count DESC'
    ).all(userId);
    res.json(weakTopics);
  } catch (error) {
    console.error('Error fetching weak topics:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/review - get daily review session
router.get('/review', authenticateToken, async (req, res) => {
  const userId = req.user.userId;

  try {
    const weakTopics = db.prepare(
      'SELECT wt.topic_id, t.title, t.content FROM weak_topics wt JOIN topics t ON wt.topic_id = t.id WHERE wt.user_id = ? ORDER BY wt.last_wrong_at ASC LIMIT 3'
    ).all(userId);

    if (weakTopics.length === 0) {
      return res.json({ message: 'No weak topics to review today.' });
    }

    const reviewQuestions = [];
    for (const topic of weakTopics) {
      const questions = await generateReviewQuestions(topic.title, topic.content);
      reviewQuestions.push({ topicId: topic.topic_id, topicTitle: topic.title, questions });
    }

    res.json(reviewQuestions);
  } catch (error) {
    console.error('Error generating review session:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
