const express = require('express');
const db = require('./db');
const { authenticateToken } = require('./auth');

const router = express.Router();

// POST /api/topics - create topic
router.post('/', authenticateToken, (req, res) => {
  const { title, content } = req.body;
  const userId = req.user.userId;

  if (!title || !content) {
    return res.status(400).json({ message: 'Title and content are required' });
  }

  try {
    const stmt = db.prepare('INSERT INTO topics (user_id, title, content) VALUES (?, ?, ?)');
    const info = stmt.run(userId, title, content);
    res.status(201).json({ message: 'Topic created successfully', topicId: info.lastInsertRowid, id: info.lastInsertRowid });
  } catch (error) {
    console.error('Error creating topic:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/topics - list user's topics
router.get('/', authenticateToken, (req, res) => {
  const userId = req.user.userId;

  try {
    const topics = db.prepare('SELECT id, title, content, created_at FROM topics WHERE user_id = ? ORDER BY created_at DESC').all(userId);
    res.json(topics);
  } catch (error) {
    console.error('Error fetching topics:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
