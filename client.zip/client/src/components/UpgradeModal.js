import React from 'react';
import './UpgradeModal.css';

const UpgradeModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal-content card">
        <h2>Upgrade to Pro</h2>
        <p>You've reached your daily limit of 5 quizzes.</p>
        <p>Upgrade to Pro for €5-10/month for unlimited quizzes and advanced explanations!</p>
        <button onClick={onClose}>Close</button>
        {/* Add a placeholder for an upgrade button if needed */}
        {/* <button className="upgrade-button">Upgrade Now</button> */}
      </div>
    </div>
  );
};

export default UpgradeModal;
