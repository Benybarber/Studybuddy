const express = require('express');
const db = require('./db');
const { authenticateToken } = require('./auth');
const { generateExplanation } = require('./openaiService');

const router = express.Router();

// Helper to save explanation to DB
const saveExplanation = (topicId, style, content, keyPoints) => {
  const stmt = db.prepare('INSERT INTO explanations (topic_id, style, content, key_points) VALUES (?, ?, ?, ?)');
  const info = stmt.run(topicId, style, content, keyPoints);
  return info.lastInsertRowid;
};

// POST /api/explain - generate explanation
router.post('/', authenticateToken, async (req, res) => {
  const { topicId, style } = req.body;
  const userId = req.user.userId;

  if (!topicId || !style) {
    return res.status(400).json({ message: 'Topic ID and style are required' });
  }

  try {
    const topic = db.prepare('SELECT title, content FROM topics WHERE id = ? AND user_id = ?').get(topicId, userId);
    if (!topic) {
      return res.status(404).json({ message: 'Topic not found or does not belong to user' });
    }

    const { content, key_points } = await generateExplanation(topic.title, topic.content, style);
    const explanationId = saveExplanation(topicId, style, content, key_points);

    res.status(201).json({ explanationId, content, key_points: JSON.parse(key_points) });
  } catch (error) {
    console.error('Error generating explanation:', error);
    res.status(500).json({ message: error.message });
  }
});

// POST /api/explain/different - re-explain same topic in a different style
router.post('/different', authenticateToken, async (req, res) => {
  const { topicId, style } = req.body;
  const userId = req.user.userId;

  if (!topicId || !style) {
    return res.status(400).json({ message: 'Topic ID and style are required' });
  }

  try {
    const topic = db.prepare('SELECT title, content FROM topics WHERE id = ? AND user_id = ?').get(topicId, userId);
    if (!topic) {
      return res.status(404).json({ message: 'Topic not found or does not belong to user' });
    }

    const { content, key_points } = await generateExplanation(topic.title, topic.content, style);
    const explanationId = saveExplanation(topicId, style, content, key_points);

    res.status(201).json({ explanationId, content, key_points: JSON.parse(key_points) });
  } catch (error) {
    console.error('Error re-generating explanation:', error);
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
