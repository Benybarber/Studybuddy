import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AuthPage from './pages/AuthPage';
import Dashboard from './pages/Dashboard';
import StudyPage from './pages/StudyPage';
import QuizPage from './pages/QuizPage';
import ReviewPage from './pages/ReviewPage';
import PrivateRoute from './components/PrivateRoute';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<AuthPage />} />
          <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
          <Route path="/study" element={<PrivateRoute><StudyPage /></PrivateRoute>} />
          <Route path="/quiz/:quizId" element={<PrivateRoute><QuizPage /></PrivateRoute>} />
          <Route path="/review" element={<PrivateRoute><ReviewPage /></PrivateRoute>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
