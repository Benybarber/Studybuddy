const express = require('express');
const db = require('./db');
const { authenticateToken } = require('./auth');

const router = express.Router();

// GET /api/stats - get basic stats (quizzes taken today for free tier limit of 5/day)
router.get('/', authenticateToken, (req, res) => {
  const userId = req.user.userId;
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

  try {
    const quizzesTakenToday = db.prepare(
      'SELECT COUNT(*) as count FROM quiz_attempts WHERE user_id = ? AND created_at LIKE ? || "%"'
    ).get(userId, today);

    res.json({
      quizzesTakenToday: quizzesTakenToday.count,
      quizLimit: 5, // Hardcoded for free tier
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
