require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db'); // Initialize database

const authRoutes = require('./auth');
const topicRoutes = require('./topics');
const explanationRoutes = require('./explanations');
const quizRoutes = require('./quizzes');
const statsRoutes = require('./stats');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
app.post('/api/auth/register', authRoutes.register);
app.post('/api/auth/login', authRoutes.login);

app.use('/api/topics', topicRoutes);
app.use('/api/explain', explanationRoutes);
app.use('/api/quiz', quizRoutes);
app.use('/api/stats', statsRoutes);

// Serve React build in production
const clientBuildPath = path.join(__dirname, '..', 'client', 'build');
app.use(express.static(clientBuildPath));

// All non-API routes serve the React app
app.use((req, res, next) => {
  if (req.method === 'GET' && !req.path.startsWith('/api')) {
    res.sendFile(path.join(clientBuildPath, 'index.html'));
  } else {
    next();
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on port ${PORT}`);
});
